#!/bin/sh

CURDIR=`pwd`
JASON_HOME=`dirname $0`
cd "$JASON_HOME/.."
JASON_HOME=`pwd`
cd $CURDIR

java -classpath "/Users/pieter/Downloads/jacamo-0-2/libs/jason-2.3-SNAPSHOT.jar" jason.util.asl2tex $1